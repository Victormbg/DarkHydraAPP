import { Component } from '@angular/core';

@Component({
  selector: 'app-sobre-incial',
  templateUrl: 'sobre.page.html',
  styleUrls: ['sobre.page.scss'],
})
export class HomePage {

  constructor() {}

}
