import { Component } from '@angular/core';

@Component({
  selector: 'app-politica-incial',
  templateUrl: 'politica.page.html',
  styleUrls: ['politica.page.scss'],
})
export class PoliticaPage {

  constructor() {}

}