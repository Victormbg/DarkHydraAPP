import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-amigos',
  templateUrl: './pagina-amigos.page.html',
  styleUrls: ['./pagina-amigos.page.scss'],
})
export class PaginaAmigosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
