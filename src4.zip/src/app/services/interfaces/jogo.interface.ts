export interface Jogos{
    idJogo?: string
    tituloJogo?: string
    descJogo?: string
    tagsJogo?: string
    imagem1?: string
    imagem2?: string
    imagem3?: string
    imagem4?: string

}